SELECT [Employee ID]
      ,[SuperVisor_ID]
  FROM [Union_Bank_OLTP].[dbo].[employee]
