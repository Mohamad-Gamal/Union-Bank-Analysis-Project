SELECT [BranchId]
      ,[BranchName]
      ,[Branch_Location]
  FROM [Union_Bank_OLTP].[dbo].[Branch]
