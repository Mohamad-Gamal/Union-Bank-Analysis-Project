SELECT [Transaction_Type_Id]
      ,[TransactionType]
  FROM [Union_Bank_OLTP].[dbo].[Transcations]
